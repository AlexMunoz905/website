For each data set, we have the following files:

A          : the mutation matrix of m rows (samples) and n columns (genes).
E (optional) : the expression matrix of m rows (samples) and n columns (genes).

